"""AI anomaly detection components."""
