"""Pure, low-latency detection for raw Apache access-log lines."""

from __future__ import annotations

from dataclasses import dataclass
from collections import deque
from datetime import datetime, timezone
import re

from .security_markers import match_security_marker


_REQUEST_LINE = re.compile(r'"(?P<method>[A-Z]+) (?P<path>\S+) [^"]+"')
_ACCESS_LINE = re.compile(
    r'^(?P<ip>\S+) .*?"(?P<method>[A-Z]+) (?P<path>\S+) [^"]+" (?P<status>\d{3}) '
)


@dataclass(frozen=True)
class EarlyDetection:
    rule_id: str
    marker: str
    method: str
    path: str
    ip: str | None = None


@dataclass(frozen=True)
class _WindowEntry:
    timestamp: float
    path: str
    is_wp_login: bool
    is_4xx: bool


class ShortWindowDetector:
    """Bounded per-IP correlation state for preliminary alerts."""

    def __init__(self, ttl_seconds: int = 60, cooldown_seconds: int = 60, max_ips: int = 10000) -> None:
        self.ttl_seconds = max(1, ttl_seconds)
        self.cooldown_seconds = max(0, cooldown_seconds)
        self.max_ips = max(1, max_ips)
        self._windows: dict[str, deque[_WindowEntry]] = {}
        self._last_alert: dict[tuple[str, str], float] = {}

    def observe(self, raw_line: str | None, now: float | None = None) -> list[EarlyDetection]:
        parsed = _ACCESS_LINE.search(raw_line or "")
        if not parsed:
            return []
        stamp = now if now is not None else datetime.now(timezone.utc).timestamp()
        ip = parsed.group("ip")
        path = parsed.group("path")
        entries = self._windows.setdefault(ip, deque())
        entries.append(_WindowEntry(
            stamp, path, "/wp-login.php" in path.lower(), parsed.group("status").startswith("4")
        ))
        self._expire(stamp)
        self._enforce_capacity()
        current = list(entries)
        candidates: list[tuple[str, str]] = []
        sensitive = detect_raw_line(raw_line)
        if sensitive:
            candidates.append((sensitive.rule_id, sensitive.marker))
        if sum(item.is_wp_login for item in current) > 20:
            candidates.append(("WEB-BRUTE-001", "wp_login_burst"))
        if len(current) >= 100:
            candidates.append(("WEB-BURST-001", "request_burst"))
        if len({item.path for item in current}) > 80:
            candidates.append(("WEB-SCAN-001", "path_scan"))
        result = []
        for rule_id, marker in candidates:
            key = (ip, rule_id)
            if stamp - self._last_alert.get(key, float("-inf")) < self.cooldown_seconds:
                continue
            self._last_alert[key] = stamp
            result.append(EarlyDetection(rule_id, marker, parsed.group("method"), path, ip))
        return result

    def _expire(self, now: float) -> None:
        cutoff = now - self.ttl_seconds
        for ip in tuple(self._windows):
            window = self._windows[ip]
            while window and window[0].timestamp <= cutoff:
                window.popleft()
            if not window:
                del self._windows[ip]
        for key, stamp in tuple(self._last_alert.items()):
            if now - stamp >= self.cooldown_seconds:
                del self._last_alert[key]

    def active_ip_count(self, now: float | None = None) -> int:
        self._expire(now if now is not None else datetime.now(timezone.utc).timestamp())
        return len(self._windows)

    def _enforce_capacity(self) -> None:
        while len(self._windows) > self.max_ips:
            oldest_ip = min(self._windows, key=lambda ip: self._windows[ip][-1].timestamp)
            del self._windows[oldest_ip]


def detect_raw_line(raw_line: str | None) -> EarlyDetection | None:
    """Detect high-confidence path probes without DB, network, or async work."""
    if not raw_line:
        return None
    request = _REQUEST_LINE.search(raw_line)
    if not request:
        return None
    match = match_security_marker(request.group("path"))
    if not match:
        return None
    rule_id, marker = match
    return EarlyDetection(
        rule_id=rule_id,
        marker=marker,
        method=request.group("method"),
        path=request.group("path"),
        ip=raw_line.split(None, 1)[0] if raw_line.split(None, 1) else None,
    )
