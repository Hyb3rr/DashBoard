from contextlib import asynccontextmanager

from fastapi import Body, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, PlainTextResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
import asyncio
import ipaddress
import json
import os
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from .config import settings
from .config.settings import APP_DIR
from .core import db as db_module
from .core.db import connect, decode, region_profile
from .core.logs import effective_risk, rebuild_observations_for_ips
from .core.buckets import upsert_buckets
from .core.enrichment import _maxmind
from .core.intelligence import classify_ip
from .tools.calibration import csv_text
from .services.profiles import (
    attach_region_and_classification,
    ai_profile_for_ip,
    classification_observation,
    ensure_profile,
    ensure_profile_postgres,
)
from .services.dispositions import set_disposition, STATES
from .services.classification_watcher import run_classification_watcher
from .services.classification import build_classification_snapshot, detection_snapshot
from .core.rules import ruleset_hash, ruleset_health
from .collectors.websocket_collector import bus, collector
from .core.intel_updater import run_due_sources
from .db import clickhouse as clickhouse_store
from .db import postgres as postgres_store
from .db.repositories import StateRepository, DispositionRepository


@asynccontextmanager
async def lifespan(_app: FastAPI):
    if settings.DATA_BACKEND == "split":
        postgres_store.ensure_schema()
        clickhouse_store.health()
    else:
        connect().close()
        await asyncio.to_thread(_migrate_legacy_file_events)
    await collector.start()
    watcher = asyncio.create_task(run_classification_watcher())
    intel_task = None
    if os.getenv("INTEL_AUTO_UPDATE_ON_STARTUP", "false").strip().lower() in {"1", "true", "yes", "on"}:
        intel_task = asyncio.create_task(
            asyncio.to_thread(run_due_sources), name="intel-startup-update"
        )
    try:
        yield
    finally:
        watcher.cancel()
        if intel_task:
            intel_task.cancel()
        await collector.stop()


app = FastAPI(title="Remote Web Monitoring Hub - IP Intelligence", lifespan=lifespan)


@app.middleware("http")
async def timing_middleware(request, call_next):
    started = time.perf_counter()
    response = await call_next(request)
    response.headers["X-Process-Time-ms"] = f"{(time.perf_counter() - started) * 1000:.1f}"
    return response


app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000", "http://localhost:8000", "null"],
    allow_origin_regex=r"^(null|https?://(localhost|127\.0\.0\.1)(:\d+)?)$",
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


def _mode_path(mode: str = "live"):
    if not isinstance(mode, str):
        mode = "live"
    if mode not in {"live", "file"}:
        raise HTTPException(400, "Invalid dataset mode")
    return settings.FILE_DB_PATH if mode == "file" else db_module.DB_PATH


def _connect_mode(mode: str = "live"):
    if settings.DATA_BACKEND == "split" and mode == "live":
        raise RuntimeError("SQLite live backend is disabled in DATA_BACKEND=split")
    return connect(_mode_path(mode))


def _migrate_legacy_file_events() -> None:
    """Move file-import rows from the old mixed DB into the file DB once."""
    if settings.FILE_DB_PATH.resolve() == db_module.DB_PATH.resolve():
        return
    live = connect(db_module.DB_PATH)
    file_db = connect(settings.FILE_DB_PATH)
    columns = (
        "source", "line_hash", "raw_line", "timestamp", "src_ip", "method",
        "path", "status", "bytes_sent", "referer", "user_agent",
        "source_offset", "imported_at",
    )
    try:
        legacy = live.execute(
            "SELECT " + ",".join(columns) + " FROM events WHERE source LIKE 'file:%'"
        ).fetchall()
        if not legacy:
            return
        affected = {row["src_ip"] for row in legacy}
        file_db.executemany(
            "INSERT OR IGNORE INTO events (" + ",".join(columns) + ") VALUES (" + ",".join("?" for _ in columns) + ")",
            [tuple(row[column] for column in columns) for row in legacy],
        )
        live.execute("DELETE FROM events WHERE source LIKE 'file:%'")
        for conn in (live, file_db):
            placeholders = ",".join("?" for _ in affected)
            params = tuple(sorted(affected))
            for table in ("ip_time_buckets", "ip_path_stats", "ip_time_bucket_paths", "ip_observations"):
                conn.execute(f"DELETE FROM {table} WHERE ip IN ({placeholders})", params)
            rows = conn.execute(
                "SELECT timestamp,src_ip,method,path,status,bytes_sent,user_agent FROM events WHERE src_ip IN (" + placeholders + ")",
                params,
            ).fetchall()
            if rows:
                upsert_buckets(conn, [dict(row) for row in rows])
                rebuild_observations_for_ips(conn, tuple(sorted(affected)))
            conn.commit()
        placeholders = ",".join("?" for _ in affected)
        live.execute(
            "DELETE FROM ip_profiles WHERE ip IN (" + placeholders + ") "
            "AND NOT EXISTS (SELECT 1 FROM events e WHERE e.src_ip = ip_profiles.ip)",
            tuple(sorted(affected)),
        )
        live.commit()
        file_db.commit()
    finally:
        live.close()
        file_db.close()


def _dataset_bounds(mode: str, ip: str | None = None) -> tuple[datetime | None, datetime | None]:
    conn = _connect_mode(mode)
    try:
        where = "WHERE timestamp IS NOT NULL"
        params: tuple[str, ...] = ()
        if ip:
            where += " AND src_ip = ?"
            params = (ip,)
        row = conn.execute(
            f"SELECT MIN(timestamp) AS start, MAX(timestamp) AS end FROM events {where}",
            params,
        ).fetchone()
        return _parse_traffic_time(row["start"] if row else None), _parse_traffic_time(row["end"] if row else None)
    finally:
        conn.close()


def _build_ip_details_sync(ip: str, refresh: bool, mode: str) -> tuple[dict | None, str | None]:
    """Build an IP detail response entirely inside one worker thread.

    SQLite connections are thread-affine by default.  Opening the connection
    inside this worker avoids moving a connection created by the ASGI thread
    across threads while keeping profile IO and classification off the event
    loop.
    """
    conn = _connect_mode(mode)
    try:
        data, error = asyncio.run(ensure_profile(conn, ip, refresh=refresh))
        if error or not data:
            return data, error
        obs = conn.execute(
            "SELECT * FROM ip_observations WHERE ip = ?", (ip,)
        ).fetchone()
        if obs:
            obs_data = dict(obs)
            obs_data["behavior_evidence"] = decode(
                obs_data.pop("behavior_evidence_json")
            )
            obs_data["behavior_evidence_recent"] = decode(
                obs_data.pop("behavior_evidence_recent_json")
            )
            obs_data["detections"] = decode(obs_data.pop("detections_json", "[]"))
            if mode == "file":
                # Uploaded logs are evaluated over their own historical
                # window. Do not let the wall-clock recent-24h fields erase
                # evidence from a file captured years ago.
                obs_data["recent_behavior_score"] = obs_data.get("behavior_score", 0)
                obs_data["recent_requests"] = obs_data.get("requests", 0)
                obs_data["recent_sensitive_probe_requests"] = obs_data.get(
                    "sensitive_probe_requests", 0
                )
            data["observation"] = obs_data
            data["effective_risk_score"], data["effective_risk_level"] = effective_risk(
                data.get("risk_score"), obs["behavior_score"]
            )
            attach_region_and_classification(
                conn,
                data,
                obs_data,
                use_supplied_observation=mode == "file",
            )
        else:
            attach_region_and_classification(conn, data, None)
        conn.commit()
        return data, None
    finally:
        conn.close()


@app.get("/", response_class=HTMLResponse)
def dashboard():
    return HTMLResponse((APP_DIR / "dashboard.html").read_text())


@app.get("/ip/{ip}", response_class=HTMLResponse)
def ip_case_page(ip: str):
    """Serve a stable full-page investigation view for one IP address."""
    try:
        ipaddress.ip_address(ip)
    except ValueError as exc:
        raise HTTPException(400, "Invalid IP address") from exc
    html = (APP_DIR / "ip_detail.html").read_text()
    return HTMLResponse(html)


@app.get("/regions", response_class=HTMLResponse)
def region_profiles_page():
    return HTMLResponse((APP_DIR / "regions.html").read_text())


@app.get("/regions/{country_code}", response_class=HTMLResponse)
def region_profile_page(country_code: str):
    """Serve the shell even for unknown codes so the page degrades cleanly."""
    return HTMLResponse((APP_DIR / "region_detail.html").read_text())

@app.get("/health")
def health():
    if settings.DATA_BACKEND != "split":
        connect().close()
    rules_health = ruleset_health()
    storage = {"backend": settings.DATA_BACKEND}
    if settings.DATA_BACKEND == "split":
        storage["postgres"] = postgres_store.health()
        storage["clickhouse"] = clickhouse_store.health()
    healthy = rules_health["status"] == "ok" and all(
        item.get("status") == "ok" for item in storage.values() if isinstance(item, dict) and "status" in item
    )
    return {
        "status": "ok" if healthy else "degraded",
        "mode": settings.DATA_BACKEND,
        "rules": rules_health,
        "storage": storage,
    }


def _split_allowed_country_ips(country_code: str, exclude: bool = False) -> list[str]:
    if exclude:
        return []
    try:
        with postgres_store.transaction() as conn:
            rows = conn.execute(
                "SELECT ip::text AS ip FROM ip_profiles WHERE country_code = %s",
                (country_code.upper(),),
            ).fetchall()
        return [str(row["ip"]) for row in rows]
    except Exception as exc:
        raise HTTPException(503, f"PostgreSQL country state unavailable: {exc}") from exc


def _traffic_from_split(
    start_stamp: datetime,
    end_stamp: datetime,
    bucket_seconds: int,
    range_name: str,
    range_label: str,
    source: str,
    filter_type: str | None,
    filter_value: str | None,
    exclude: bool,
) -> dict:
    if source == "file":
        dataset_id = "file"
    else:
        dataset_id = settings.DATASET_LIVE_ID
    allowed_ips = None
    if filter_type == "country":
        allowed_ips = _split_allowed_country_ips(str(filter_value), exclude)
    try:
        result = clickhouse_store.traffic(
            start_stamp,
            end_stamp,
            bucket_seconds,
            dataset_id=dataset_id,
            filter_type=filter_type,
            filter_value=filter_value,
            exclude=exclude,
            allowed_ips=allowed_ips,
        )
    except Exception as exc:
        raise HTTPException(503, f"ClickHouse traffic unavailable: {exc}") from exc
    now = datetime.now(timezone.utc)
    result.update({
        "bucket": f"{bucket_seconds // 60}min" if bucket_seconds < 3600 else f"{bucket_seconds // 3600}h",
        "range": range_name,
        "range_label": range_label,
        "start": start_stamp.isoformat(),
        "end": end_stamp.isoformat(),
        "filter": {"type": filter_type, "value": filter_value, "exclude": bool(exclude)} if filter_type else None,
        "source": source,
        "as_of": now.isoformat(),
    })
    return result


@app.get("/api/analytics/traffic")
def traffic_analytics(
    range_key: str = Query("1h", alias="range"),
    start: str | None = None,
    end: str | None = None,
    filter_type: str | None = None,
    filter_value: str | None = None,
    exclude: bool = False,
    source: str = Query("all", pattern="^(all|stream|file)$"),
    mode: str = Query("live", pattern="^(live|file)$"),
):
    """Aggregate one traffic event set for the Overview time window."""
    # Direct Python callers/tests do not receive FastAPI's default value from
    # Query(), so normalize those values before applying dataset routing.
    if not isinstance(mode, str):
        mode = "live"
    if not isinstance(source, str):
        source = "all"
    ranges = {
        "30m": (30 * 60, 5 * 60, "last 30 minutes"),
        "1h": (60 * 60, 10 * 60, "last 1 hour"),
        "6h": (6 * 60 * 60, 30 * 60, "last 6 hours"),
        "12h": (12 * 60 * 60, 60 * 60, "last 12 hours"),
        "1d": (24 * 60 * 60, 2 * 60 * 60, "last 24 hours"),
        "3d": (3 * 24 * 60 * 60, 6 * 60 * 60, "last 3 days"),
        "7d": (7 * 24 * 60 * 60, 12 * 60 * 60, "last 7 days"),
        "30d": (30 * 24 * 60 * 60, 24 * 60 * 60, "last 30 days"),
    }
    selected = ranges.get(range_key, ranges["1h"])
    now = datetime.now(timezone.utc)
    end_stamp = _parse_traffic_time(end) if end else now
    if mode == "file" and not start and not end:
        file_start, file_end = _dataset_bounds(mode)
        if file_start and file_end:
            start_stamp, end_stamp = file_start, file_end
        else:
            start_stamp = None
    else:
        start_stamp = _parse_traffic_time(start) if start else end_stamp - timedelta(seconds=selected[0])
    if end_stamp is None or (mode == "live" and end_stamp > now):
        end_stamp = now
    if start_stamp is None:
        start_stamp = end_stamp - timedelta(seconds=selected[0])
    if start_stamp is None or end_stamp <= start_stamp:
        raise HTTPException(400, "Invalid traffic time range")
    bucket_seconds = selected[1]
    range_label = "custom window" if start else selected[2]
    range_name = "custom" if start else range_key
    window_seconds = max(60, int((end_stamp - start_stamp).total_seconds()))
    if start:
        bucket_seconds = max(60, min(3600, window_seconds // 12))
    if filter_type not in {None, "ip", "path", "country"} or (filter_type and not filter_value):
        raise HTTPException(400, "Invalid traffic filter")
    if settings.DATA_BACKEND == "split":
        return _traffic_from_split(
            start_stamp,
            end_stamp,
            bucket_seconds,
            range_name,
            range_label,
            source,
            filter_type,
            filter_value,
            exclude,
        )
    conn = _connect_mode(mode)
    try:
        where = ["e.timestamp IS NOT NULL", "e.timestamp >= ?", "e.timestamp <= ?"]
        params: list[str] = [start_stamp.isoformat(), end_stamp.isoformat()]
        if source == "stream":
            where.append("e.source LIKE 'ws:%'")
        elif source == "file":
            where.append("e.source LIKE 'file:%'")
        if filter_type == "ip":
            where.append("e.src_ip != ?" if exclude else "e.src_ip = ?")
            params.append(str(filter_value))
        elif filter_type == "path":
            where.append("e.path != ?" if exclude else "e.path = ?")
            params.append(str(filter_value))
        elif filter_type == "country":
            where.append("COALESCE(p.country_code, '') != ?" if exclude else "p.country_code = ?")
            params.append(str(filter_value).upper())
        rows = conn.execute(
            f"""
            SELECT e.timestamp, e.src_ip, e.path, e.status, p.country_code, p.country
            FROM events e LEFT JOIN ip_profiles p ON p.ip = e.src_ip
            WHERE {' AND '.join(where)}
            ORDER BY e.timestamp ASC
            """,
            params,
        ).fetchall()
        parsed = []
        for row in rows:
            try:
                stamp = datetime.fromisoformat(str(row["timestamp"]).replace("Z", "+00:00"))
                if stamp.tzinfo is None:
                    stamp = stamp.replace(tzinfo=timezone.utc)
                parsed.append((stamp.astimezone(timezone.utc), row))
            except (TypeError, ValueError):
                continue
        grid_start = datetime.fromtimestamp((start_stamp.timestamp() // bucket_seconds) * bucket_seconds, timezone.utc)
        bucket_count = max(1, int((end_stamp.timestamp() - grid_start.timestamp()) // bucket_seconds) + 1)
        bucket_starts = [grid_start + timedelta(seconds=i * bucket_seconds) for i in range(bucket_count)]
        buckets = {stamp.isoformat().replace("+00:00", "Z"): {"requests": 0, "errors": 0} for stamp in bucket_starts}
        paths, countries, ips = Counter(), Counter(), Counter()
        status_codes = {"2xx": 0, "3xx": 0, "4xx": 0, "5xx": 0}
        path_ips, country_ips = defaultdict(set), defaultdict(set)
        for stamp, row in parsed:
            index = int((stamp.timestamp() - grid_start.timestamp()) // bucket_seconds)
            index = max(0, min(bucket_count - 1, index))
            bucket = bucket_starts[index]
            item = buckets[bucket.isoformat().replace("+00:00", "Z")]
            item["requests"] += 1
            status = int(row["status"] or 0)
            if status >= 400:
                item["errors"] += 1
            family = f"{status // 100}xx"
            if family in status_codes:
                status_codes[family] += 1
            if row["path"]:
                path = str(row["path"])
                paths[path] += 1
                path_ips[path].add(str(row["src_ip"]))
            country = row["country_code"] or "Unknown"
            country_key = (str(country), str(row["country"] or country))
            countries[country_key] += 1
            country_ips[country_key].add(str(row["src_ip"]))
            ips[str(row["src_ip"])] += 1
        series = [{"timestamp": key, **buckets[key]} for key in buckets]
        return {
            "series": series,
            "bucket": f"{bucket_seconds // 60}min" if bucket_seconds < 3600 else f"{bucket_seconds // 3600}h",
            "range": range_name,
            "range_label": range_label,
            "start": start_stamp.isoformat(),
            "end": end_stamp.isoformat(),
            "status_codes": status_codes,
            "top_paths": [{"path": key, "requests": value, "ips": sorted(path_ips[key])} for key, value in paths.most_common(8)],
            "top_countries": [{"country_code": key[0], "country": key[1], "requests": value, "ips": sorted(country_ips[key])} for key, value in countries.most_common(8)],
            "top_ips": [{"ip": key, "requests": value} for key, value in ips.most_common(8)],
            "total_requests": len(parsed),
            "error_requests": sum(item["errors"] for item in buckets.values()),
            "unique_ips": len(ips),
            "unique_countries": len(countries),
            "filter": {"type": filter_type, "value": filter_value, "exclude": bool(exclude)} if filter_type else None,
            "source": source,
            "as_of": now.isoformat(),
        }
    finally:
        conn.close()


@app.get("/api/ip/{ip}/traffic")
def ip_traffic(ip: str, range_key: str = Query("1h", alias="range"), start: str | None = None, end: str | None = None, mode: str = Query("live", pattern="^(live|file)$")):
    """Return one IP's traffic view from persisted aggregates.

    Only the recent forensic list reads raw events.  Timeline and status
    totals come from minute buckets, and top paths come from ip_path_stats.
    """
    try:
        address = str(ipaddress.ip_address(ip))
    except ValueError as exc:
        raise HTTPException(400, "Invalid IP address") from exc
    ranges = {"30m": 1800, "1h": 3600, "6h": 21600, "12h": 43200, "1d": 86400, "3d": 259200, "7d": 604800}
    seconds = ranges.get(range_key, ranges["1h"])
    now = datetime.now(timezone.utc)
    end_stamp = _parse_traffic_time(end) if end else now
    if mode == "file" and not start and not end:
        file_start, file_end = _dataset_bounds(mode, address)
        if file_start and file_end:
            start_stamp, end_stamp = file_start, file_end
        else:
            start_stamp = None
    else:
        start_stamp = _parse_traffic_time(start) if start else end_stamp - timedelta(seconds=seconds)
    if end_stamp is None or (mode == "live" and end_stamp > now):
        end_stamp = now
    if start_stamp is None:
        start_stamp = end_stamp - timedelta(seconds=seconds)
    if not start_stamp or not end_stamp or end_stamp <= start_stamp:
        raise HTTPException(400, "Invalid traffic time range")
    seconds = max(60, int((end_stamp - start_stamp).total_seconds()))
    bucket_seconds = max(60, min(3600, seconds // 12))
    if settings.DATA_BACKEND == "split" and mode == "live":
        try:
            result = clickhouse_store.traffic_for_ip(
                start_stamp, end_stamp, bucket_seconds, address, settings.DATASET_LIVE_ID
            )
        except Exception as exc:
            raise HTTPException(503, f"ClickHouse traffic unavailable: {exc}") from exc
        result.update({
            "ip": address, "range": range_key, "range_label": f"last {range_key}",
            "start": start_stamp.isoformat(), "end": end_stamp.isoformat(),
            "as_of": now.isoformat(),
        })
        return result
    conn = _connect_mode(mode)
    try:
        _ensure_ip_aggregates(conn, address)
        grid_start = datetime.fromtimestamp((start_stamp.timestamp() // bucket_seconds) * bucket_seconds, timezone.utc)
        bucket_count = max(1, int((end_stamp.timestamp() - grid_start.timestamp()) // bucket_seconds) + 1)
        bucket_starts = [grid_start + timedelta(seconds=i * bucket_seconds) for i in range(bucket_count)]
        buckets = {stamp.isoformat().replace("+00:00", "Z"): {"requests": 0, "errors": 0} for stamp in bucket_starts}
        status_codes = {"2xx": 0, "3xx": 0, "4xx": 0, "5xx": 0}
        bucket_rows = conn.execute(
            """
            SELECT bucket_minute, requests, status_2xx, status_3xx,
                   status_4xx, status_5xx
            FROM ip_time_buckets
            WHERE ip = ? AND bucket_minute >= ? AND bucket_minute <= ?
            ORDER BY bucket_minute
            """,
            (
                address,
                grid_start.isoformat(),
                bucket_starts[-1].isoformat(),
            ),
        ).fetchall()
        for row in bucket_rows:
            try:
                stamp = datetime.fromisoformat(str(row["bucket_minute"]).replace("Z", "+00:00"))
            except ValueError:
                continue
            key = stamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
            if key not in buckets:
                continue
            item = buckets[key]
            item["requests"] = int(row["requests"] or 0)
            item["errors"] = sum(int(row[column] or 0) for column in ("status_4xx", "status_5xx"))
            for family in status_codes:
                status_codes[family] += int(row[f"status_{family}"] or 0)

        path_rows = conn.execute(
            """
            SELECT path, SUM(requests) AS requests,
                   SUM(status_4xx + status_5xx) AS errors,
                   MIN(bucket_minute) AS first_seen, MAX(bucket_minute) AS last_seen
            FROM ip_time_bucket_paths
            WHERE ip = ? AND bucket_minute >= ? AND bucket_minute <= ? AND path IS NOT NULL
            GROUP BY path
            ORDER BY requests DESC, path ASC
            LIMIT 12
            """,
            (address, grid_start.isoformat(), bucket_starts[-1].isoformat()),
        ).fetchall()
        if not path_rows or not any(int(row["requests"] or 0) for row in path_rows):
            # Legacy aggregates created before path-time counters existed.
            # New ingest never takes this branch; keep old databases useful
            # until their one-time backfill is run.
            path_rows = conn.execute(
                """SELECT path, COUNT(*) AS requests,
                          SUM(CASE WHEN status >= 400 THEN 1 ELSE 0 END) AS errors,
                          MIN(timestamp) AS first_seen, MAX(timestamp) AS last_seen
                   FROM events
                  WHERE src_ip=? AND timestamp>=? AND timestamp<=? AND path IS NOT NULL
                  GROUP BY path ORDER BY requests DESC, path ASC LIMIT 12""",
                (address, start_stamp.isoformat(), end_stamp.isoformat()),
            ).fetchall()
        recent_rows = conn.execute(
            """
            SELECT timestamp, method, path, status
            FROM events
            WHERE src_ip = ? AND timestamp IS NOT NULL
              AND timestamp >= ? AND timestamp <= ?
            ORDER BY timestamp DESC
            LIMIT 50
            """,
            (address, start_stamp.isoformat(), end_stamp.isoformat()),
        ).fetchall()
        recent = [
            {
                "timestamp": str(row["timestamp"]).replace("+00:00", "Z"),
                "method": row["method"] or "—",
                "path": row["path"] or "—",
                "status": row["status"],
            }
            for row in reversed(recent_rows)
        ]
        total_requests = sum(item["requests"] for item in buckets.values())
        return {
            "ip": address, "range": range_key, "range_label": f"last {range_key}",
            "start": start_stamp.isoformat(), "end": end_stamp.isoformat(), "as_of": now.isoformat(),
            "total_requests": total_requests, "series": [{"timestamp": key, **buckets[key]} for key in buckets],
            "status_codes": status_codes,
            "top_paths": [dict(row) for row in path_rows],
            "recent_requests": recent,
        }
    finally:
        conn.close()

def _parse_traffic_time(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except ValueError:
        return None


def _ensure_ip_aggregates(conn, address: str) -> None:
    """Repair only legacy/directly-seeded IPs missing persisted aggregates."""
    exists = conn.execute(
        "SELECT 1 FROM ip_time_buckets WHERE ip = ? LIMIT 1", (address,)
    ).fetchone()
    if exists:
        return
    rows = conn.execute(
        """
        SELECT timestamp, src_ip, method, path, status, bytes_sent, user_agent
        FROM events
        WHERE src_ip = ? AND timestamp IS NOT NULL
        """,
        (address,),
    ).fetchall()
    if rows:
        upsert_buckets(conn, [dict(row) for row in rows])
        conn.commit()

@app.get("/api/ip/{ip}/paths")
def ip_path_activity(ip: str, limit: int = 12, mode: str = Query("live", pattern="^(live|file)$")):
    if settings.DATA_BACKEND == "split" and mode == "live":
        raise HTTPException(410, "Path Activity endpoint is retired in split live mode; use IP Traffic")
    """Return lifetime path aggregates for one IP."""
    try:
        address = str(ipaddress.ip_address(ip))
    except ValueError as exc:
        raise HTTPException(400, "Invalid IP address") from exc

    limit = min(max(limit, 1), 50)
    conn = _connect_mode(mode)
    try:
        _ensure_ip_aggregates(conn, address)
        total_row = conn.execute(
            "SELECT COALESCE(SUM(requests), 0) AS requests "
            "FROM ip_path_stats WHERE ip = ?",
            (address,),
        ).fetchone()
        total = int(total_row["requests"] or 0) if total_row else 0
        rows = conn.execute(
            """SELECT path, requests,
                      status_4xx + status_5xx AS errors,
                      first_seen, last_seen
                 FROM ip_path_stats
                WHERE ip = ?
                ORDER BY requests DESC, path ASC
                LIMIT ?""",
            (address, limit),
        ).fetchall()
        paths = []
        for row in rows:
            item = dict(row)
            item["requests"] = int(item["requests"] or 0)
            item["errors"] = int(item["errors"] or 0)
            item["share"] = round(item["requests"] / total, 4) if total else 0
            paths.append(item)
        return {"ip": address, "total_requests": total, "paths": paths}
    finally:
        conn.close()


@app.get("/api/ip/{ip}")
async def ip_details(ip: str, refresh: bool = False, mode: str = Query("live", pattern="^(live|file)$")):
    try:
        address = ipaddress.ip_address(ip)
    except ValueError as exc:
        raise HTTPException(400, "Invalid IP address") from exc
    if settings.DATA_BACKEND == "split" and mode == "live":
        if refresh:
            data, error = await ensure_profile_postgres(str(address), refresh=True)
            if error:
                raise HTTPException(502, f"Enrichment provider unavailable: {error}")
        row = await asyncio.to_thread(StateRepository().get, str(address))
        if not row:
            raise HTTPException(404, "IP not found")
        return _pg_item(row)
    data, error = await asyncio.to_thread(
        _build_ip_details_sync, str(address), refresh, mode
    )
    if error:
        raise HTTPException(502, f"Enrichment provider unavailable: {error}")
    return data


@app.get("/api/ip/{ip}/attack")
def ip_attack(ip: str, window: str = Query("24h"), mode: str = Query("live", pattern="^(live|file)$")):
    """Return recent observed detections and their explicit techniques."""
    try:
        address = str(ipaddress.ip_address(ip))
    except ValueError as exc:
        raise HTTPException(400, "Invalid IP address") from exc
    if window not in {"1h", "24h"}:
        raise HTTPException(400, "Unsupported attack window")
    if settings.DATA_BACKEND == "split" and mode == "live":
        row = StateRepository().get(address)
        payload = dict((row or {}).get("observation_payload") or {})
        suffix = "1h" if window == "1h" else "24h"
        detections = payload.get(f"detections_{suffix}", []) or []
        by_technique: dict[str, dict] = {}
        for detection in detections:
            technique = detection.get("mitre_technique")
            if technique:
                item = by_technique.setdefault(technique, {"id": technique, "detection_ids": []})
                if detection.get("id") not in item["detection_ids"]:
                    item["detection_ids"].append(detection.get("id"))
        return {
            "ip": address, "window": window,
            "ruleset_hash": payload.get(f"ruleset_hash_{suffix}"),
            "evaluated_at": payload.get(f"evaluated_at_{suffix}"),
            "detections": detections, "techniques": list(by_technique.values()),
        }
    conn = _connect_mode(mode)
    try:
        persisted = detection_snapshot(conn, address, window)
        detections = persisted["detections"]
        techniques = []
        by_technique = {}
        for detection in detections:
            technique = detection.get("mitre_technique")
            if technique:
                item = by_technique.setdefault(technique, {"id": technique, "detection_ids": []})
                if detection.get("id") not in item["detection_ids"]:
                    item["detection_ids"].append(detection.get("id"))
        techniques = list(by_technique.values())
        return {
            "ip": address,
            "window": window,
            "ruleset_hash": persisted["ruleset_hash"],
            "evaluated_at": persisted["evaluated_at"],
            "detections": detections,
            "techniques": techniques,
        }
    finally:
        conn.close()


@app.post("/api/ip/{ip}/disposition")
def update_ip_disposition(ip: str, payload: dict = Body(...)):
    try:
        address = str(ipaddress.ip_address(ip))
    except ValueError as exc:
        raise HTTPException(400, "Invalid IP address") from exc
    state = str(payload.get("state") or "").lower()
    if state not in STATES:
        raise HTTPException(400, "Invalid disposition state")
    if settings.DATA_BACKEND == "split":
        current = StateRepository().get(address)
        label = current.get("label") if current else None
        return DispositionRepository().set(
            address, state, payload.get("assigned_to"), payload.get("note"),
            payload.get("actor") or "system", label,
        )
    conn = connect()
    try:
        row = conn.execute("SELECT * FROM ip_observations WHERE ip=?", (address,)).fetchone()
        profile = conn.execute("SELECT * FROM ip_profiles WHERE ip=?", (address,)).fetchone()
        label = None
        if row:
            item = dict(row)
            if profile:
                label = build_classification_snapshot(conn, address).classification.get("label")
        result = set_disposition(conn, address, state, payload.get("assigned_to"), payload.get("note"), payload.get("actor") or "system", label)
        return result
    finally:
        conn.close()


@app.get("/api/regions/demand-signal")
def region_demand_signal(limit: int = 50):
    """Aggregate observed, likely-legitimate traffic by country.

    This is an analyst signal, not a claim about individual identity or
    market demand.  It counts good-classified IPs with real requests while
    excluding privacy/hosting signals, bots, and sensitive probes, then joins
    the country profile's sourced context.
    """
    if settings.DATA_BACKEND == "split":
        raise HTTPException(503, "Region demand state is not migrated to PostgreSQL yet")
    limit = min(max(limit, 1), 200)
    conn = connect()
    try:
        rows = conn.execute(
            """
            SELECT p.*, o.first_seen, o.last_seen, o.requests, o.status_4xx,
                   o.status_5xx, o.unique_paths, o.wp_login_requests,
                   o.sensitive_probe_requests, o.bot_requests, o.behavior_score,
                   o.behavior_score_recent, o.recent_requests, o.behavior_evidence_json,
                   o.behavior_evidence_recent_json
            FROM ip_profiles p
            LEFT JOIN ip_observations o ON o.ip = p.ip
            WHERE p.country_code IS NOT NULL
            """
        ).fetchall()
        # Load the small AI snapshot once. The previous loop reread profile,
        # observation and history tables repeatedly for every IP.
        ai_by_ip = {}
        for ai_row in conn.execute("SELECT * FROM ip_ai_scores").fetchall():
            ai_item = dict(ai_row)
            ai_item["ai_evidence"] = decode(ai_item.pop("ai_evidence_json", "[]"))
            ai_by_ip[ai_item["ip"]] = ai_item
        region_cache = {}
        aggregates = {}
        for raw in rows:
            item = dict(raw)
            item["identity_evidence"] = decode(item.pop("identity_evidence_json", "[]"))
            item["provider_errors"] = decode(item.pop("provider_errors_json", "[]"))
            item["provider_status"] = decode(item.pop("provider_status_json", "{}"))
            item["field_sources"] = decode(item.pop("field_sources_json", "{}"))
            item["reputation"] = decode(item.pop("reputation_json", "[]"))
            item["evidence"] = decode(item.pop("evidence_json", "[]"))
            item["sources"] = decode(item.pop("source_json", "[]"))
            item["behavior_evidence"] = decode(item.pop("behavior_evidence_json", "[]"))
            code = item["country_code"]
            if code not in region_cache:
                region_cache[code] = region_profile(conn, code) or {
                    "country_code": code,
                    "country_name": item.get("country") or code,
                }
            region = region_cache[code]
            observation = classification_observation(item)
            observation["behavior_evidence"] = item.get("behavior_evidence", [])
            classification = classify_ip(
                item,
                observation,
                region,
                ai_by_ip.get(item["ip"]),
            )
            entry = aggregates.setdefault(code, {
                "country_code": code,
                "country_name": region.get("country_name") or item.get("country") or code,
                "observed_ip_count": 0,
                "observed_requests": 0,
                "good_ip_count": 0,
                "classified_good_ip_count": 0,
                "good_requests": 0,
                "watch_ip_count": 0,
                "bad_ip_count": 0,
                "unknown_ip_count": 0,
                "privacy_signal_ip_count": 0,
                "profile_updated_at": region.get("updated_at"),
                "economic_indicators": region.get("economic_indicators", {}),
                "market_components": region.get("market_components", {}),
                "market_score": region.get("market_score"),
                "market_level": region.get("market_level", "unknown"),
                "product_opportunities": region.get("product_opportunities", []),
                "cultural_context": region.get("cultural_context", []),
                "conflict_indicators": region.get("conflict_indicators", []),
                "sources": region.get("sources", []),
            })
            requests = int(item.get("requests") or 0)
            label = classification["label"]
            entry["observed_ip_count"] += 1
            entry["observed_requests"] += requests
            if label == "good":
                entry["classified_good_ip_count"] += 1
            else:
                entry[f"{label}_ip_count"] += 1
            privacy_signal = any(item.get(field) == 1 for field in ("is_tor", "is_vpn", "is_proxy", "is_hosting"))
            if privacy_signal:
                entry["privacy_signal_ip_count"] += 1
            eligible = (
                label == "good" and requests > 0 and not privacy_signal
                and int(item.get("sensitive_probe_requests") or 0) == 0
                and int(item.get("bot_requests") or 0) == 0
            )
            if eligible:
                entry["good_requests"] += requests
                entry["good_ip_count"] += 1

        results = []
        for entry in aggregates.values():
            total = entry["observed_requests"]
            good_ips = entry["good_ip_count"]
            entry["good_traffic_share"] = round(entry["good_requests"] / total, 4) if total else 0
            entry["signal_level"] = (
                "high" if entry["good_requests"] >= 500 else
                "medium" if entry["good_requests"] >= 50 else
                "low" if entry["good_requests"] > 0 else "none"
            )
            entry["product_demand"] = (entry.get("market_components") or {}).get("product_demand")
            entry["analyst_note"] = "Observed good traffic signal; validate with conversion and customer data before market decisions." if good_ips else "No qualifying good traffic observed in the current window."
            results.append(entry)
        results.sort(key=lambda x: (x["good_requests"], x["observed_requests"]), reverse=True)
        return results[:limit]
    finally:
        conn.close()


@app.get("/api/regions/{country_code}")
def region_details(country_code: str):
    if settings.DATA_BACKEND == "split":
        raise HTTPException(503, "Region profiles are not migrated to PostgreSQL yet")
    conn = connect()
    try:
        data = region_profile(conn, country_code.upper())
        if not data:
            raise HTTPException(404, "Region profile not found")
        return data
    finally:
        conn.close()


@app.get("/api/ips/calibration.csv", response_class=PlainTextResponse)
def calibration_export():
    """Export current predictions and signals for manual labeling."""
    return PlainTextResponse(
        csv_text(list_ips(limit=5000)),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=ip-calibration.csv"},
    )


@app.get("/api/regions")
def region_list(limit: int = 50):
    if settings.DATA_BACKEND == "split":
        raise HTTPException(503, "Region profiles are not migrated to PostgreSQL yet")
    limit = min(max(limit, 1), 200)
    conn = connect()
    try:
        rows = conn.execute(
            """
            SELECT country_code, country_name, updated_at
            FROM region_profiles
            ORDER BY country_name ASC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        items = []
        for row in rows:
            profile = region_profile(conn, row["country_code"])
            if profile:
                items.append(profile)
        return items
    finally:
        conn.close()

@app.post("/api/ips/refresh-unknown")
async def refresh_unknown(limit: int = 500, mode: str = Query("live", pattern="^(live|file)$")):
    """Stream local-only enrichment results, highest-request IP first.

    Response format is NDJSON: one JSON object per line. Every IP is committed
    and yielded immediately after its local lookup finishes. No online provider
    is called by enrichment.lookup().
    """
    limit = min(max(limit, 1), 5000)

    if settings.DATA_BACKEND == "split" and mode == "live":
        with postgres_store.transaction() as pg_conn:
            rows = pg_conn.execute("""SELECT host(o.ip) AS ip
                FROM ip_observations_state o LEFT JOIN ip_profiles p ON p.ip=o.ip
                WHERE p.ip IS NULL OR p.enrichment_status IS DISTINCT FROM 'complete'
                   OR p.country IS NULL OR p.country_code IS NULL
                ORDER BY COALESCE(NULLIF(o.payload->>'requests','')::bigint,0) DESC, o.ip ASC
                LIMIT %s""", (limit,)).fetchall()
        selected = [str(row["ip"]) for row in rows]

        async def generate_split():
            yield json.dumps({"type": "start", "selected": len(selected), "mode": "live", "order": "requests_desc"}) + "\n"
            processed = complete = partial = failed = 0
            for ip in selected:
                data, error = await ensure_profile_postgres(ip, refresh=True)
                processed += 1
                if data and not error:
                    complete += 1
                    status = "complete"
                elif data:
                    partial += 1
                    status = "partial"
                else:
                    failed += 1
                    status = "failed"
                yield json.dumps({"type": "item", "ip": ip, "status": status, "error": error}) + "\n"
            yield json.dumps({"type": "done", "selected": len(selected), "processed": processed, "complete": complete, "partial": partial, "failed": failed}) + "\n"

        return StreamingResponse(generate_split(), media_type="application/x-ndjson", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    # Select before streaming so the DB read cursor is not held for the whole run.
    select_conn = _connect_mode(mode)
    rows = select_conn.execute("""
        SELECT
          o.ip AS ip,
          COALESCE(o.requests, 0) AS requests,
          p.core_enrichment_status,
          p.country, p.country_code, p.latitude, p.longitude
        FROM ip_observations o
        LEFT JOIN ip_profiles p ON p.ip = o.ip
        WHERE p.ip IS NULL
           OR p.core_enrichment_status IS NULL
           OR p.core_enrichment_status != 'complete'
           OR p.privacy_enrichment_status IS NULL
           OR p.privacy_enrichment_status != 'complete'
           OR p.country IS NULL OR p.country_code IS NULL
           OR p.latitude IS NULL OR p.longitude IS NULL
        ORDER BY COALESCE(o.requests, 0) DESC, o.ip ASC
        LIMIT ?
    """, (limit,)).fetchall()
    selected = [dict(row) for row in rows]
    select_conn.close()

    async def generate():
        yield json.dumps({
            "type": "start",
            "selected": len(selected),
            "mode": "local_only",
            "order": "requests_desc",
        }) + "\n"

        conn = _connect_mode(mode)
        complete = partial = failed = processed = 0
        # Lookups are local disk/mmap reads (see enrichment.py), so several IPs
        # can genuinely be resolved at the same time instead of strictly one
        # after another. CHUNK_SIZE also sets how many rows share one
        # conn.commit(): committing every single IP was forcing a disk sync per
        # row, which dominated total mapping time far more than the lookups
        # themselves. Batching commits removes that overhead almost entirely
        # while still surfacing progress every CHUNK_SIZE rows.
        CHUNK_SIZE = 12
        try:
            for chunk_start in range(0, len(selected), CHUNK_SIZE):
                chunk = selected[chunk_start:chunk_start + CHUNK_SIZE]
                started = time.perf_counter()

                # Fire off this chunk's lookups concurrently; order of the
                # results list matches the order of `chunk` (asyncio.gather
                # guarantee), so priority order (highest requests first) is
                # preserved in the stream even though completion order inside
                # the chunk may vary.
                results = await asyncio.gather(*[
                    ensure_profile(conn, row["ip"], refresh=True) for row in chunk
                ])

                for offset, (row, (data, error)) in enumerate(zip(chunk, results)):
                    index = chunk_start + offset + 1
                    ip = row["ip"]
                    requests = row["requests"]
                    elapsed_ms = round((time.perf_counter() - started) * 1000, 2)

                    if error:
                        failed += 1
                        payload = {
                            "type": "ip",
                            "index": index,
                            "total": len(selected),
                            "ip": ip,
                            "requests": requests,
                            "status": "failed",
                            "error": error,
                            "elapsed_ms": elapsed_ms,
                        }
                    else:
                        processed += 1
                        status = data.get("core_enrichment_status", "failed")
                        if status == "complete":
                            complete += 1
                        elif status == "partial":
                            partial += 1
                        else:
                            failed += 1

                        payload = {
                            "type": "ip",
                            "index": index,
                            "total": len(selected),
                            "ip": ip,
                            "requests": requests,
                            "status": status,
                            "country": data.get("country"),
                            "country_code": data.get("country_code"),
                            "region": data.get("region"),
                            "city": data.get("city"),
                            "latitude": data.get("latitude"),
                            "longitude": data.get("longitude"),
                            "asn": data.get("asn"),
                            "organization": data.get("organization"),
                            "sources": data.get("sources", []),
                            "provider_errors": data.get("provider_errors", []),
                            "elapsed_ms": elapsed_ms,
                        }

                    # One line becomes visible to curl/browser as soon as this IP finishes.
                    yield json.dumps(payload, ensure_ascii=False) + "\n"

                # One commit per chunk instead of one per IP.
                conn.commit()

            yield json.dumps({
                "type": "done",
                "selected": len(selected),
                "processed": processed,
                "complete": complete,
                "partial": partial,
                "failed": failed,
            }) + "\n"
        finally:
            conn.close()

    return StreamingResponse(
        generate(),
        media_type="application/x-ndjson",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )

@app.get("/api/ips")
def list_ips(limit: int = 100, mode: str = Query("live", pattern="^(live|file)$")):
    if settings.DATA_BACKEND == "split" and mode == "live":
        bounded = min(max(limit, 1), 50)
        result = StateRepository().page(1, bounded, "threat_signal_score", "desc")
        return [_pg_item(row) for row in result["rows"]]
    conn = _connect_mode(mode)
    try:
        return _build_ip_items(conn, limit=min(max(limit, 1), 500), mode=mode)
    finally:
        conn.close()


def _page_ip_keys(
    conn,
    page: int,
    page_size: int,
    sort: str,
    direction: str,
    q: str | None,
    privacy: str | None,
    classification: str | None,
    disposition: str | None,
):
    sort_columns = {
        "threat_signal_score": "COALESCE(cs.score, o.behavior_score, 0)",
        "requests": "COALESCE(o.requests, 0)",
        "status_4xx": "COALESCE(o.status_4xx, 0)",
        "unique_paths": "COALESCE(o.unique_paths, 0)",
        "last_seen": "COALESCE(o.last_seen, p.fetched_at)",
    }
    order = sort_columns.get(sort, sort_columns["threat_signal_score"])
    order_direction = "ASC" if str(direction).lower() == "asc" else "DESC"
    where = ["1=1"]
    params: list[object] = []
    if q:
        term = f"%{q.strip()}%"
        where.append("(i.ip LIKE ? OR COALESCE(p.country, '') LIKE ? OR COALESCE(p.country_code, '') LIKE ? OR COALESCE(p.asn, '') LIKE ? OR COALESCE(p.organization, '') LIKE ?)")
        params.extend([term] * 5)
    if privacy == "privacy":
        where.append("(COALESCE(p.is_tor, 0)=1 OR COALESCE(p.is_vpn, 0)=1 OR COALESCE(p.is_proxy, 0)=1)")
    elif privacy == "tor":
        where.append("COALESCE(p.is_tor, 0)=1")
    elif privacy == "hosting":
        where.append("COALESCE(p.is_hosting, 0)=1")
    if classification:
        where.append("COALESCE(cs.label, 'unknown') = ?")
        params.append(classification)
    if disposition:
        where.append("COALESCE(d.state, 'new') = ?")
        params.append(disposition)
    where_sql = " AND ".join(where)
    base = f"""
        WITH identities AS (
          SELECT ip FROM ip_observations
          UNION
          SELECT ip FROM ip_profiles
        )
        SELECT i.ip
        FROM identities i
        LEFT JOIN ip_observations o ON o.ip=i.ip
        LEFT JOIN ip_profiles p ON p.ip=i.ip
        LEFT JOIN ip_classification_state cs ON cs.ip=i.ip
        LEFT JOIN ip_dispositions d ON d.ip=i.ip
        WHERE {where_sql}
        ORDER BY {order} {order_direction}, COALESCE(o.requests, 0) DESC, i.ip ASC
        LIMIT ? OFFSET ?
    """
    offset = (max(1, page) - 1) * page_size
    params.extend([page_size, offset])
    return [str(row["ip"]) for row in conn.execute(base, params).fetchall()]


@app.get("/api/ips/page")
def ip_page(
    page: int = 1,
    page_size: int = 50,
    sort: str = "threat_signal_score",
    direction: str = "desc",
    q: str | None = None,
    privacy: str | None = None,
    classification: str | None = None,
    disposition: str | None = None,
    mode: str = Query("live", pattern="^(live|file)$"),
):
    page = max(1, int(page))
    page_size = min(50, max(1, int(page_size)))
    if settings.DATA_BACKEND == "split" and mode == "live":
        result = StateRepository().page(page, page_size, sort, direction, q, privacy, classification, disposition)
        return {
            "items": [_pg_item(row) for row in result["rows"]], "page": page, "page_size": page_size,
            "total_items": result["total"], "total_pages": (result["total"] + page_size - 1) // page_size,
            "change_cursor": result["cursor"], "snapshot_at": datetime.now(timezone.utc).isoformat(),
        }
    conn = _connect_mode(mode)
    try:
        where = ["1=1"]
        params: list[object] = []
        if q:
            term = f"%{q.strip()}%"
            where.append("(i.ip LIKE ? OR COALESCE(p.country, '') LIKE ? OR COALESCE(p.country_code, '') LIKE ? OR COALESCE(p.asn, '') LIKE ? OR COALESCE(p.organization, '') LIKE ?)")
            params.extend([term] * 5)
        if privacy == "privacy":
            where.append("(COALESCE(p.is_tor, 0)=1 OR COALESCE(p.is_vpn, 0)=1 OR COALESCE(p.is_proxy, 0)=1)")
        elif privacy == "tor":
            where.append("COALESCE(p.is_tor, 0)=1")
        elif privacy == "hosting":
            where.append("COALESCE(p.is_hosting, 0)=1")
        if classification:
            where.append("COALESCE(cs.label, 'unknown') = ?")
            params.append(classification)
        if disposition:
            where.append("COALESCE(d.state, 'new') = ?")
            params.append(disposition)
        where_sql = " AND ".join(where)
        total = int(conn.execute(f"""
            WITH identities AS (SELECT ip FROM ip_observations UNION SELECT ip FROM ip_profiles)
            SELECT COUNT(*) AS n FROM identities i
            LEFT JOIN ip_observations o ON o.ip=i.ip
            LEFT JOIN ip_profiles p ON p.ip=i.ip
            LEFT JOIN ip_classification_state cs ON cs.ip=i.ip
            LEFT JOIN ip_dispositions d ON d.ip=i.ip
            WHERE {where_sql}
        """, params).fetchone()["n"])
        keys = _page_ip_keys(conn, page, page_size, sort, direction, q, privacy, classification, disposition)
        items = _build_ip_items(conn, set(keys), mode=mode)
        by_ip = {item["ip"]: item for item in items}
        ordered = [by_ip[ip] for ip in keys if ip in by_ip]
        return {
            "items": ordered, "page": page, "page_size": page_size,
            "total_items": total, "total_pages": (total + page_size - 1) // page_size,
            "change_cursor": _change_cursor(conn),
            "snapshot_at": datetime.now(timezone.utc).isoformat(),
        }
    finally:
        conn.close()


@app.get("/api/ips/summary")
def ip_summary(mode: str = Query("live", pattern="^(live|file)$")):
    if settings.DATA_BACKEND == "split" and mode == "live":
        summary = StateRepository().summary()
        summary["priority_items"] = _pg_items(summary.pop("priority_ips"))
        summary["ai"] = {"scored": 0, "flagged": 0, "coverage": 0}
        summary["snapshot_at"] = datetime.now(timezone.utc).isoformat()
        return summary
    conn = _connect_mode(mode)
    try:
        row = conn.execute("""
          WITH identities AS (SELECT ip FROM ip_observations UNION SELECT ip FROM ip_profiles)
          SELECT COUNT(*) AS total,
            SUM(CASE WHEN COALESCE(cs.label, 'unknown')='bad' THEN 1 ELSE 0 END) AS bad,
            SUM(CASE WHEN COALESCE(cs.label, 'unknown')='watch' THEN 1 ELSE 0 END) AS watch,
            SUM(CASE WHEN COALESCE(cs.label, 'unknown')='good' THEN 1 ELSE 0 END) AS good,
            SUM(CASE WHEN COALESCE(cs.label, 'unknown')='unknown' THEN 1 ELSE 0 END) AS unknown,
            SUM(CASE WHEN COALESCE(p.is_tor,0)=1 OR COALESCE(p.is_vpn,0)=1 OR COALESCE(p.is_proxy,0)=1 THEN 1 ELSE 0 END) AS privacy
          FROM identities i
          LEFT JOIN ip_classification_state cs ON cs.ip=i.ip
          LEFT JOIN ip_profiles p ON p.ip=i.ip
        """).fetchone()
        ai = conn.execute(
            """SELECT COUNT(*) AS scored,
                      SUM(CASE WHEN ai_anomaly_score >= 70 THEN 1 ELSE 0 END) AS flagged
                 FROM ip_ai_scores s
                 JOIN (SELECT ip FROM ip_observations UNION SELECT ip FROM ip_profiles) i ON i.ip=s.ip"""
        ).fetchone()
        top_keys = [str(r["ip"]) for r in conn.execute(
            "SELECT ip FROM ip_classification_state WHERE label IN ('bad','watch') ORDER BY score DESC, ip ASC LIMIT 5"
        ).fetchall()]
        top = _build_ip_items(conn, set(top_keys), mode=mode)
        by_ip = {item["ip"]: item for item in top}
        return {
            "total_ips": int(row["total"] or 0),
            "classification": {key: int(row[key] or 0) for key in ("bad", "watch", "good", "unknown")},
            "privacy": {"total": int(row["privacy"] or 0)},
            "ai": {"scored": int(ai["scored"] or 0), "flagged": int(ai["flagged"] or 0),
                   "coverage": round((int(ai["scored"] or 0) / int(row["total"] or 1)) * 100, 2)},
            "priority_items": [by_ip[ip] for ip in top_keys if ip in by_ip],
            "snapshot_at": datetime.now(timezone.utc).isoformat(),
        }
    finally:
        conn.close()


def _ip_rows(conn, only_ips: set[str] | None = None):
    first_where = ""
    second_where = "WHERE o.ip IS NULL"
    params: list[str] = []
    if only_ips:
        placeholders = ",".join("?" for _ in only_ips)
        values = sorted(only_ips)
        first_where = f"WHERE o.ip IN ({placeholders})"
        second_where = f"WHERE o.ip IS NULL AND p.ip IN ({placeholders})"
        params.extend(values)
        params.extend(values)
    return conn.execute(f"""
        SELECT
          COALESCE(o.ip, p.ip) AS ip,
          p.country, p.country_code, p.city, p.region, p.latitude, p.longitude,
          p.timezone, p.asn, p.organization, p.isp,
          p.network_type, p.ip_prefix, COALESCE(p.organization_confidence, 0) AS organization_confidence,
          p.abuse_score, p.abuse_reports,
          p.is_hosting, p.is_vpn, p.is_proxy, p.is_tor,
          p.enrichment_status, p.core_enrichment_status, p.privacy_enrichment_status, p.threat_enrichment_status, p.next_retry_at,
          p.provider_status_json, p.field_sources_json,
          p.network_location_json, COALESCE(p.location_confidence, 0) AS location_confidence,
          COALESCE(p.location_disputed, 0) AS location_disputed, p.location_scope,
          COALESCE(p.risk_score, 0) AS profile_risk_score,
          COALESCE(o.behavior_score, 0) AS behavior_score,
          COALESCE(o.behavior_score_recent, 0) AS behavior_score_recent,
          COALESCE(o.requests, 0) AS requests,
          COALESCE(o.recent_requests, 0) AS recent_requests,
          COALESCE(o.recent_sensitive_probe_requests, 0) AS recent_sensitive_probe_requests,
          o.recent_first_seen AS recent_first_seen,
          o.recent_updated_at AS recent_updated_at,
          COALESCE(o.status_4xx, 0) AS status_4xx,
          COALESCE(o.status_5xx, 0) AS status_5xx,
          COALESCE(o.unique_paths, 0) AS unique_paths,
          COALESCE(o.wp_login_requests, 0) AS wp_login_requests,
          COALESCE(o.sensitive_probe_requests, 0) AS sensitive_probe_requests,
          o.first_seen, o.last_seen, p.fetched_at
        FROM ip_observations o
        LEFT JOIN ip_profiles p ON p.ip = o.ip
        {first_where}
        UNION
        SELECT
          p.ip, p.country, p.country_code, p.city, p.region, p.latitude, p.longitude,
          p.timezone, p.asn, p.organization, p.isp,
          p.network_type, p.ip_prefix, p.organization_confidence, p.abuse_score, p.abuse_reports,
          p.is_hosting, p.is_vpn, p.is_proxy, p.is_tor,
          p.enrichment_status, p.core_enrichment_status, p.privacy_enrichment_status, p.threat_enrichment_status, p.next_retry_at,
          p.provider_status_json, p.field_sources_json,
          p.network_location_json, COALESCE(p.location_confidence, 0), COALESCE(p.location_disputed, 0), p.location_scope,
          p.risk_score, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, p.fetched_at
        FROM ip_profiles p
        LEFT JOIN ip_observations o ON o.ip = p.ip
        {second_where}
        """, params).fetchall()


def _build_ip_items(conn, only_ips: set[str] | None = None, limit: int | None = None, mode: str = "live"):
    rows = _ip_rows(conn, only_ips)
    if limit and not only_ips and len(rows) > limit:
        # Bound classification work before attaching per-IP DB-backed fields.
        rows = sorted(
            rows,
            key=lambda row: (int(row["behavior_score"] or 0), int(row["requests"] or 0)),
            reverse=True,
        )[:limit]
    items = []
    for row in rows:
        item = dict(row)
        item["provider_status"] = decode(item.pop("provider_status_json"))
        item["field_sources"] = decode(item.pop("field_sources_json"))
        item["network_location"] = decode(item.pop("network_location_json"))
        item["location_disputed"] = bool(item.get("location_disputed"))
        if mode == "file" and not item.get("country"):
            # File observations may be new to the file DB and therefore have
            # no persisted profile yet. MaxMind is a fast local read, so use
            # it as a display fallback rather than rendering every identity
            # as Unknown while the full detail enrichment is pending.
            try:
                geo, _, state = _maxmind(item["ip"])
            except Exception:
                geo, state = {}, "failed"
            if geo:
                if not isinstance(item["field_sources"], dict):
                    item["field_sources"] = {}
                for field in ("country", "country_code", "city", "region", "latitude", "longitude", "timezone", "asn", "organization"):
                    if geo.get(field) is not None:
                        item[field] = geo[field]
                item["organization_confidence"] = max(int(item.get("organization_confidence") or 0), 60)
                item["location_confidence"] = max(int(item.get("location_confidence") or 0), 60)
                item["location_disputed"] = False
                item["location_scope"] = "network"
                item["network_location"] = {
                    "country": geo.get("country"),
                    "country_code": geo.get("country_code"),
                    "scope": "network",
                    "confidence": item["location_confidence"],
                    "sources": ["MaxMind City/ASN"],
                }
                item["field_sources"] = {
                    **item["field_sources"],
                    **{field: "MaxMind City/ASN" for field in ("country", "country_code", "city", "asn", "organization") if geo.get(field) is not None},
                }
                item["enrichment_status"] = "partial"
                item["core_enrichment_status"] = "partial"
                item["provider_status"] = {"MaxMind City/ASN": {"status": state}}
        item["effective_risk_score"], item["effective_risk_level"] = effective_risk(item["profile_risk_score"], item["behavior_score"])
        # Keep Overview classification identical to IP Detail.  The detail
        # endpoint classifies from the durable observation totals; passing the
        # empty recent window here made the same IP appear as threat 0.
        observation = {
            "behavior_score": item["behavior_score"],
            "requests": item["requests"],
            "status_4xx": item["status_4xx"],
            "status_5xx": item["status_5xx"],
            "unique_paths": item["unique_paths"],
            "wp_login_requests": item["wp_login_requests"],
            "sensitive_probe_requests": item["sensitive_probe_requests"],
        }
        attach_region_and_classification(
            conn,
            item,
            observation,
            use_supplied_observation=mode == "file",
            persist_disposition=False,
        )
        items.append(item)
    return sorted(items, key=lambda item: (item["threat_signal_score"], item["requests"]), reverse=True)


def _pg_item(row: dict) -> dict:
    """Build the dashboard contract from the PostgreSQL state read model."""
    observation = dict(row.get("observation_payload") or {})
    observation.setdefault("recent_behavior_score", observation.get("behavior_score", 0))
    observation.setdefault("behavior_evidence", observation.get("recent_behavior_evidence", []))
    profile = {key: value for key, value in row.items() if key not in {"observation_payload", "label", "classification_score", "classification_confidence", "disposition"}}
    profile["ip"] = str(row.get("ip") or observation.get("ip") or profile.get("ip"))
    for key in ("identity_evidence", "reputation", "provider_errors", "provider_status", "field_sources", "evidence", "sources"):
        if profile.get(key) is None:
            profile[key] = [] if key in {"identity_evidence", "reputation", "provider_errors", "evidence", "sources"} else {}
    classification = classify_ip(profile, observation, {}, None)
    if row.get("label"):
        classification["label"] = row["label"]
        classification["score"] = int(row.get("classification_score") or classification["score"])
        classification["confidence"] = int(row.get("classification_confidence") or classification.get("confidence", 0))
    item = {
        **profile,
        "ip": profile["ip"],
        "observation": observation,
        "classification": classification,
        "threat_signal_score": int(classification.get("score", 0)),
        "threat_signal_label": classification.get("label", "unknown"),
        "disposition": {"state": row.get("disposition") or "new"},
        "profile_risk_score": int(profile.get("risk_score") or 0),
        "effective_risk_score": int(classification.get("score", 0)),
        "effective_risk_level": classification.get("label", "unknown"),
        "requests": int(observation.get("requests") or 0),
        "status_4xx": int(observation.get("status_4xx") or 0),
        "status_5xx": int(observation.get("status_5xx") or 0),
        "unique_paths": int(observation.get("unique_paths") or 0),
        "first_seen": observation.get("first_seen"),
        "last_seen": observation.get("last_seen"),
    }
    return item


def _pg_items(ips: list[str] | set[str]) -> list[dict]:
    repo = StateRepository()
    return [_pg_item(row) for row in repo.get_many(ips)]


def _change_cursor(conn) -> int:
    return int(conn.execute("SELECT COALESCE(MAX(seq), 0) AS seq FROM ip_change_log").fetchone()["seq"])


@app.get("/api/ips/snapshot")
def ip_snapshot(limit: int = 500, mode: str = Query("live", pattern="^(live|file)$")):
    if settings.DATA_BACKEND == "split" and mode == "live":
        bounded = min(max(limit, 1), 500)
        result = StateRepository().page(1, bounded, "threat_signal_score", "desc")
        return {"items": [_pg_item(row) for row in result["rows"]], "cursor": result["cursor"], "snapshot_at": datetime.now(timezone.utc).isoformat()}
    conn = _connect_mode(mode)
    try:
        bounded = min(max(limit, 1), 500)
        return {
            "items": _build_ip_items(conn, limit=bounded, mode=mode),
            "cursor": _change_cursor(conn),
            "snapshot_at": datetime.now(timezone.utc).isoformat(),
        }
    finally:
        conn.close()


@app.get("/api/ips/updates")
def ip_updates(after: int = 0, limit: int = 500, mode: str = Query("live", pattern="^(live|file)$")):
    limit = min(max(limit, 1), 500)
    if settings.DATA_BACKEND == "split" and mode == "live":
        result = StateRepository().changes(after, limit)
        if result.get("reset_required"):
            return {"items": [], "cursor": result["current"], "has_more": False, "reset_required": True, "transitions": []}
        rows = result["rows"]
        items = _pg_items({str(row["ip"]) for row in rows})
        return {
            "items": items,
            "transitions": [row for row in rows if row["reason"] == "classification"],
            "cursor": int(rows[-1]["seq"]) if result.get("has_more") and rows else result["current"],
            "has_more": bool(result.get("has_more")), "reset_required": False,
        }
    conn = _connect_mode(mode)
    try:
        current = _change_cursor(conn)
        oldest_row = conn.execute("SELECT MIN(seq) AS seq FROM ip_change_log").fetchone()
        oldest = int(oldest_row["seq"] or 0)
        if after and oldest and after < oldest - 1:
            return {"items": [], "cursor": current, "has_more": False, "reset_required": True}
        changed = conn.execute(
            "SELECT seq, ip, reason, old_label, new_label, old_score, new_score, changed_at FROM ip_change_log WHERE seq > ? ORDER BY seq LIMIT ?",
            (after, limit + 1),
        ).fetchall()
        has_more = len(changed) > limit
        delivered = changed[:limit]
        ips = {row["ip"] for row in delivered}
        next_cursor = int(delivered[-1]["seq"]) if has_more and delivered else current
        return {
            "items": _build_ip_items(conn, ips, mode=mode),
            "transitions": [dict(row) for row in delivered if row["reason"] == "classification"],
            "cursor": next_cursor,
            "has_more": has_more,
            "reset_required": False,
        }
    finally:
        conn.close()


@app.get("/api/collector/status")
def collector_status():
    payload = collector.status()
    if settings.DATA_BACKEND == "split":
        payload["ai_state_backend"] = "sqlite_legacy_disabled_for_live"
        return payload
    conn = connect()
    try:
        row = conn.execute("SELECT * FROM ai_model_state WHERE model_key = 'isolation_forest_v1'").fetchone()
        if row:
            payload.update({
                "ai_model_version": row["model_version"],
                "ai_trained_at": row["trained_at"],
                "ai_train_status": row["last_train_status"],
                "ai_training_windows": row["training_windows"],
                "ai_last_score_at": row["last_score_at"],
                "ai_score_status": row["last_score_status"],
                "ai_last_error": row["last_train_error"],
            })
        return payload
    finally:
        conn.close()


@app.get("/api/stream")
async def realtime_stream():
    async def generate():
        iterator = bus.subscribe().__aiter__()
        try:
            while True:
                try:
                    event, payload = await asyncio.wait_for(iterator.__anext__(), timeout=15)
                    yield f"event: {event}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"
                except asyncio.TimeoutError:
                    yield ": heartbeat\n\n"
        except (asyncio.CancelledError, StopAsyncIteration):
            return
        finally:
            await iterator.aclose()

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
