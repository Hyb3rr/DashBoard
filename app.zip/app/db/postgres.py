from __future__ import annotations

import os
from pathlib import Path
from contextlib import contextmanager
from typing import Any, Iterator


def configured() -> bool:
    return bool(os.getenv("POSTGRES_DSN"))


def connect():
    try:
        import psycopg
    except ImportError as exc:  # pragma: no cover - optional deployment extra
        raise RuntimeError("psycopg is required for DATA_BACKEND=split") from exc
    return psycopg.connect(
        os.environ["POSTGRES_DSN"],
        row_factory=psycopg.rows.dict_row,
    )


@contextmanager
def transaction() -> Iterator[Any]:
    conn = connect()
    try:
        with conn.transaction():
            yield conn
    finally:
        conn.close()


def health() -> dict[str, Any]:
    try:
        with transaction() as conn:
            conn.execute("SELECT 1")
        return {"status": "ok"}
    except Exception as exc:
        return {"status": "failed", "error": f"{type(exc).__name__}: {exc}"[:240]}


def ensure_schema() -> None:
    """Apply the idempotent local PostgreSQL schema before split traffic starts."""
    schema_path = Path(__file__).resolve().parents[2] / "infra" / "postgres" / "001_initial.sql"
    sql = schema_path.read_text(encoding="utf-8")
    with transaction() as conn:
        conn.execute(sql)


def countries_for_ips(ips: list[str]) -> dict[str, dict[str, str | None]]:
    """Resolve a compact ClickHouse IP aggregate through the PG state plane."""
    if not ips:
        return {}
    with transaction() as conn:
        rows = conn.execute(
            """SELECT host(ip) AS ip, country, country_code
               FROM ip_profiles WHERE ip = ANY(%s::inet[])""",
            (ips,),
        ).fetchall()
    return {str(row["ip"]): {"country": row["country"], "country_code": row["country_code"]} for row in rows}
