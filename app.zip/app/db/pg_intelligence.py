"""PostgreSQL-only live intelligence lookups.

This module is deliberately read-only. Feed providers may still use the
legacy updater during migration, but live enrichment never opens SQLite.
"""

from __future__ import annotations

import ipaddress
import json
from typing import Any

from .postgres import transaction
from ..core.net_utils import candidate_networks


def _candidates(ip: str) -> list[str]:
    address = ipaddress.ip_address(ip)
    return [str(ipaddress.ip_network(value, strict=False)) for value in candidate_networks(address)]


def _resolution(row: Any) -> dict[str, Any]:
    result = dict(row)
    for key in ("source_ids", "evidence"):
        value = result.get(key)
        if isinstance(value, str):
            try:
                result[key] = json.loads(value)
            except json.JSONDecodeError:
                result[key] = [] if key == "source_ids" else {}
    result["disputed"] = bool(result.get("disputed"))
    result["sources"] = result.get("source_ids") or []
    result["scope"] = result.get("location_scope") or "unknown"
    result["confidence_breakdown"] = (result.get("evidence") or {}).get("confidence_breakdown", {})
    return result


def resolve_network_location(ip: str, vendor: dict | None = None) -> dict[str, Any]:
    address = ipaddress.ip_address(ip)
    candidates = _candidates(str(address))
    vendor = vendor or {}
    with transaction() as conn:
        cached = conn.execute("SELECT * FROM geo_resolutions WHERE ip=%s AND (expires_at IS NULL OR expires_at>=now())", (str(address),)).fetchone()
        if cached:
            return _resolution(cached)
        prefixes = conn.execute("SELECT * FROM geo_prefixes WHERE active=TRUE AND network=ANY(%s::cidr[])", (candidates,)).fetchall()
        prefixes = sorted(prefixes, key=lambda row: row["network"].prefixlen if hasattr(row["network"], "prefixlen") else len(str(row["network"])), reverse=True)
        best = dict(prefixes[0]) if prefixes else {}
        operational = []
        registration = None
        if best.get("registration_country"):
            registration = {"country_code": best["registration_country"], "source": best.get("source")}
        if best:
            observations = conn.execute("SELECT * FROM geo_location_observations WHERE network=%s", (best["network"],)).fetchall()
            operational.extend(dict(row) for row in observations)
    if vendor.get("country_code"):
        operational.append({"country": vendor.get("country"), "country_code": vendor["country_code"], "source": vendor.get("geo_source", "maxmind"), "source_confidence": int(vendor.get("geo_confidence") or 60), "location_scope": "vendor"})
    if not operational and registration:
        return {"network": str(best.get("network")) if best else None, "asn": best.get("asn"), "organization": best.get("organization"), "network_type": best.get("network_type"), "country_code": registration["country_code"], "confidence": 55, "disputed": False, "scope": "registration", "sources": [registration.get("source")], "registration": registration, "confidence_breakdown": {"method": "registration_fallback", "final_score": 55}}
    if not operational:
        return {"network": str(best.get("network")) if best else None, "asn": best.get("asn"), "organization": best.get("organization"), "network_type": best.get("network_type"), "country": vendor.get("country"), "country_code": vendor.get("country_code"), "confidence": 0, "disputed": False, "scope": "unknown", "sources": [], "registration": registration, "confidence_breakdown": {"method": "no_operational_evidence", "final_score": 0}}
    groups: dict[str, list[dict]] = {}
    for item in operational:
        groups.setdefault(str(item.get("country_code") or "").upper(), []).append(item)
    code, items = max(groups.items(), key=lambda pair: sum(int(x.get("source_confidence") or 0) for x in pair[1]))
    confidence = min(100, max(int(item.get("source_confidence") or 0) for item in items) + min(16, (len(items) - 1) * 8))
    return {
        "network": str(best.get("network")) if best else None, "asn": best.get("asn"),
        "organization": best.get("organization"), "network_type": best.get("network_type"),
        "country": items[0].get("country"), "country_code": code, "confidence": confidence,
        "disputed": len(groups) > 1, "scope": items[0].get("location_scope") or "network",
        "sources": [item.get("source") for item in items if item.get("source")], "registration": registration,
        "confidence_breakdown": {"method": "weighted_consensus", "final_score": confidence, "sources": items},
    }


def local_intelligence(ip: str) -> tuple[dict, dict, dict, list[str]]:
    address = ipaddress.ip_address(ip)
    candidates = _candidates(str(address))
    result: dict[str, Any] = {}
    providers: dict[str, Any] = {}
    fields: dict[str, str] = {}
    errors: list[str] = []
    with transaction() as conn:
        privacy = conn.execute("SELECT * FROM privacy_networks WHERE active=TRUE AND network=ANY(%s::cidr[])", (candidates,)).fetchall()
        threats = conn.execute("SELECT * FROM threat_indicators WHERE active=TRUE AND network=ANY(%s::cidr[])", (candidates,)).fetchall()
    for row in privacy:
        kind = row["kind"]
        field = "is_vpn" if kind == "vpn" else "is_proxy" if kind == "proxy" else "is_hosting"
        result[field] = True
        fields[field] = str(row["source"])
        providers[str(row["source"])] = {"status": "active", "kind": kind}
        if kind == "proxy" and row.get("proxy_type"):
            result["proxy_type"] = row["proxy_type"]
    for row in threats:
        providers[str(row["source"])] = {"status": "active", "category": row["category"]}
        if row["source"] in {"firehol:firehol_proxies", "firehol:firehol_anonymous"}:
            result["is_proxy"] = True
            fields["is_proxy"] = str(row["source"])
    if threats:
        result["threat_indicators"] = [dict(row) for row in threats]
    resolution = resolve_network_location(str(address))
    if resolution.get("country_code"):
        result["network_location"] = resolution
        for key in ("asn", "organization", "network_type", "country", "country_code", "latitude", "longitude", "city"):
            if resolution.get(key) is not None:
                result[key] = resolution[key]
        providers["geo_resolution"] = {"status": "active"}
    return result, providers, fields, errors
